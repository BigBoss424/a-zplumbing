This theme is designed and brought to you free by webdevster.com

###################Instructions###################

For Magento 1.2.x

# Unzip girly_store_v.1.zip into your magento directory
# Go to Backend..System..Design..Current package name..type: girly_store
# Save Config

If you have any comments or need help, please visit me at:

http://webdevster.com/ecommerce/magento/magento-themes/girly-store-magento-theme


##################Release Notes####################

--------Package Info----------------
Name:
girly_store
Channel:
connect.magentocommerce.com/community
Summary:
Girly Store Template, free pink theme for many girly type stores. Includes Theme, PSD logo, and Font.
Description:
I created this Girly Store Template, based on the original Magento Demo Store Template layout; no core changes. The only changes I made were to the css, images, and minor changes in the theme code. 

You can either install through magento connect, or manually install by downloading magento packages from my website: http://webdevster.com/ecommerce/magento/magento-themes/girly-store-magento-theme . The packages also include the Logo PSD File and Font.

License:
OSL v3.0
License URL:
http://www.opensource.org/licenses/osl-3.0.php

---------Release Info--------------
Release Version:
1.0
API Version:
1.0
Release Stability:
Stable
API Stability:
Stable
Notes:
Stable release for use with Magento 1.2.x. 

---------Maintainers-----------------
Level:
Lead
Name:
WebDevster.com
User:
##############
Email:
##############
Status:
Active

---------Dependencies-----------------
PHP Version
Minimum:
5.2.0
Maximum:
6.0
Recommended:
5.2.0
Exclude:
6.0

---------Contents---------------------
Contents
Role:
Magento Theme Skin
Path:
app/design/frontend/girly_store
Type:
Recursive Directory

Role:
Magento Theme Skin
Path:
skin/frontend/girly_store
Type:
Recursive Directory
