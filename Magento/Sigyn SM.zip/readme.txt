------------------
Magento theme
Designed by Silverthemes (http://www.silverthemes.com)
------------------

Dear friends,

thank you for downloading this file.

This theme has been brought to you by SmashingMagazine.com and is released under GPL.
You can freely use it for both your private and commercial projects, including software, online services, templates and themes. 
Please link to the article in which this freebie was released if you would like to spread the word.

Smashing Magazine Team,
www.smashingmagazine.com
